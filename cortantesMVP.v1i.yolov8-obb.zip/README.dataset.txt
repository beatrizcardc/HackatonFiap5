# cortantesMVP > 2025-04-20 3:40pm
https://universe.roboflow.com/fiap5cortantes/cortantesmvp-xme9i

Provided by a Roboflow user
License: CC BY 4.0

